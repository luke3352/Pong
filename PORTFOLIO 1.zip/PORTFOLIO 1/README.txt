README

The first thing you will need to do is install the NodeJs command prompt.
Once that is done extract this folder and cd into the the PORTFOLIO 1 folder.
Then in the command promp type node app.js, this should start the server.
Next in your browser open up a tab and type localhost:2000, this should load the game and connect to the server.
Open another tab and also type in localhost:2000.
To start the game hit serve ball. 
Use the up and down arrow keys to control the paddle.
To control either the left or right paddle you must switch tabs.
Open up as many tabs as you want! Theres no limit to how many paddles can be on screen!
